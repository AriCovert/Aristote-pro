# Créé par 1ERE2.macquet, le 12/01/2023 en Python 3.7




#****** Mes Fonctions ***************


def lirePhrase():
    texte = input("Entrer une phrase : ")
    return texte

def codageCaractere(car):
    code = bin(ord(car))[2:]
    code = (8-len(code))*"0"+code
    return code

def codagePhrase(phrase):
    phraseCodee = ''
    for car in phrase:
        codeCar = codageCaractere(car)
        phraseCodee = phraseCodee+codeCar
    return phraseCodee

#*************  Main   ****************

phrase = lirePhrase()
codeASCII = codagePhrase(phrase)
print(codeASCII)




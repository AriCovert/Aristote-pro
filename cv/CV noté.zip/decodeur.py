# Créé par 1ERE2.macquet, le 12/01/2023 en Python 3.7




#****** Mes Fonctions ***************


def lireCode():
    code = input("Entrer une phrase en code ASCII à décoder : ")
    return code

def décodagePhrase(phraseCodee):
    phraseDecodee = ''
    while phraseCodee != '' :
        lettre = phraseCodee[0:8]
        lettre = chr(int(lettre,2))
        phraseDecodee = phraseDecodee + lettre
        phraseCodee = phraseCodee[8:]
    return phraseDecodee

#*************  Main   ****************

code = lireCode()
phraseDecodee = décodagePhrase(code)
print(phraseDecodee)




const openPopupButton = document.getElementById('openPopup');
const closePopupButton = document.getElementById('closePopup');
const popup = document.getElementById('popup');
const overlay = document.getElementById('overlay');
const yesButton = document.getElementById('yesButton');
const noButton = document.getElementById('noButton');

let popupWidth = 300;
let popupHeight = 150;
let loopActive = true;

function showPopup() {
  if (!loopActive) return;
  popup.style.width = popupWidth + 'px';
  popup.style.height = popupHeight + 'px';
  popup.style.display = 'block';
  overlay.style.display = 'block';
}

function closePopup() {
  popup.style.display = 'none';
  overlay.style.display = 'none';

  if (loopActive) {
    setTimeout(() => {
      popupWidth += 50; // Increase width
      popupHeight += 25; // Increase height
      showPopup();
    }, 100); // Reopen after 0.1 seconds
  }
}

function exitLoop() {
  loopActive = false;
  popup.style.display = 'none';
  overlay.style.display = 'none';
}

openPopupButton.addEventListener('click', showPopup);
closePopupButton.addEventListener('click', closePopup);
noButton.addEventListener('click', closePopup);
yesButton.addEventListener('click', exitLoop);

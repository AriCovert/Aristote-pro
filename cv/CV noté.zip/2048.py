# Créé par TLE2.macquet, le 20/11/2024 en Python 3.7
import pygame
import random
from pygame.locals import *

pygame.init()

# Taille de la fenêtre
TAILLE_FENETRE = 600
TAILLE_GRILLE = 4
TILE_SIZE = 125
MARGIN = 10
FONTE = pygame.font.SysFont('Arial', 40)

# Couleurs
couleur_fond = (187, 173, 160)
couleur_grille = (205, 193, 180)
couleur_tuiles = {
    2: (238, 228, 218), 4: (237, 224, 200), 8: (242, 85, 35),
    16: (245, 124, 49), 32: (245, 168, 37), 64: (245, 209, 54),
    128: (238, 223, 95), 256: (237, 204, 97), 512: (237, 200, 80),
    1024: (237, 197, 63), 2048: (237, 194, 46)
}

# Initialiser la fenêtre Pygame
fenetre = pygame.display.set_mode((TAILLE_FENETRE, TAILLE_FENETRE))
pygame.display.set_caption("2048")

# Plateau du jeu (4x4)
def init_jeu():
    grille = [[0] * TAILLE_GRILLE for _ in range(TAILLE_GRILLE)]
    ajouter_tuile(grille)
    ajouter_tuile(grille)
    return grille

def ajouter_tuile(grille):
    # Ajouter une nouvelle tuile (2 ou 4) à un endroit vide sur le plateau
    cases_vides = [(i, j) for i in range(TAILLE_GRILLE) for j in range(TAILLE_GRILLE) if grille[i][j] == 0]
    if cases_vides:
        i, j = random.choice(cases_vides)
        grille[i][j] = random.choice([2, 4])

def dessiner_grille(fenetre, grille):
    fenetre.fill(couleur_fond)

    # Dessiner les tuiles
    for i in range(TAILLE_GRILLE):
        for j in range(TAILLE_GRILLE):
            val = grille[i][j]
            x, y = j * TILE_SIZE + MARGIN, i * TILE_SIZE + MARGIN
            pygame.draw.rect(fenetre, couleur_grille, (x, y, TILE_SIZE, TILE_SIZE))

            if val != 0:
                pygame.draw.rect(fenetre, couleur_tuiles[val], (x, y, TILE_SIZE, TILE_SIZE))
                texte = FONTE.render(str(val), True, (255, 255, 255) if val > 4 else (119, 110, 101))
                fenetre.blit(texte, (x + TILE_SIZE // 2 - texte.get_width() // 2, y + TILE_SIZE // 2 - texte.get_height() // 2))

    pygame.display.update()

def fusionner_grille(grille, direction):
    if direction == 'haut':
        for j in range(TAILLE_GRILLE):
            col = [grille[i][j] for i in range(TAILLE_GRILLE)]
            col = fusionner_ligne(col)
            for i in range(TAILLE_GRILLE):
                grille[i][j] = col[i]
    elif direction == 'bas':
        for j in range(TAILLE_GRILLE):
            col = [grille[i][j] for i in range(TAILLE_GRILLE)]
            col = fusionner_ligne(col[::-1])
            for i in range(TAILLE_GRILLE):
                grille[i][j] = col[::-1][i]
    elif direction == 'gauche':
        for i in range(TAILLE_GRILLE):
            ligne = grille[i]
            grille[i] = fusionner_ligne(ligne)
    elif direction == 'droite':
        for i in range(TAILLE_GRILLE):
            ligne = grille[i]
            grille[i] = fusionner_ligne(ligne[::-1])[::-1]

def fusionner_ligne(ligne):
    # Fusionner les éléments d'une ligne
    ligne = [x for x in ligne if x != 0]
    for i in range(len(ligne) - 1):
        if ligne[i] == ligne[i + 1]:
            ligne[i] *= 2
            ligne[i + 1] = 0
    ligne = [x for x in ligne if x != 0]
    return ligne + [0] * (TAILLE_GRILLE - len(ligne))

def mouvement_possible(grille):
    # Vérifier si des mouvements sont encore possibles
    for i in range(TAILLE_GRILLE):
        for j in range(TAILLE_GRILLE - 1):
            if grille[i][j] == 0 or grille[i][j] == grille[i][j + 1]:
                return True
            if grille[j][i] == 0 or grille[j][i] == grille[j + 1][i]:
                return True
    return False

def jouer():
    grille = init_jeu()
    boucle_jeu = True

    while boucle_jeu:
        for event in pygame.event.get():
            if event.type == QUIT:
                boucle_jeu = False
            elif event.type == KEYDOWN:
                if event.key == K_UP:
                    fusionner_grille(grille, 'haut')
                elif event.key == K_DOWN:
                    fusionner_grille(grille, 'bas')
                elif event.key == K_LEFT:
                    fusionner_grille(grille, 'gauche')
                elif event.key == K_RIGHT:
                    fusionner_grille(grille, 'droite')
                ajouter_tuile(grille)

        dessiner_grille(fenetre, grille)

        # Vérifier si le jeu est terminé
        if not mouvement_possible(grille):
            print("Game Over!")
            boucle_jeu = False

        pygame.time.Clock().tick(10)

    pygame.quit()

# Démarrer le jeu
jouer()


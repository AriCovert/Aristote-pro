# Créé par Aristote Macquet, le 31/10/2023 en Python 3.7

# *************   JEU DU NOMBRE MYSTERE    *************

from  random import*

print("Bonjour nouveau joueur,"'vous voici dans "le jeu du nombre mystère",')
print("Le but est simple, l'ordinateur choisi aléatoirementun nombre entre 1 et 100 et vous devez le devinez.")
print("Pour cela, vous proposerez des nombres et l'ordinateurvous répondra si le nombre mystère est plus petit ou plus grand.")
print("Moins vous ferez de propositions, plus votre score sera grand.")
print("Mais tout d'abbord,")
joueur = input("sous quel pseudo souhaitez vous jouer? ")
print("D'accord",joueur,",grace à votre pseudo, je pourrais enregistrer votre score.")

nb_coups = 0
difficulte = 0
record = 0

reponse = "r"
while reponse == "r":
    difficulte = int(input("Choisissez votre difficulté :\nFacile: Le nombre mystère est compris entre 1 et 50 (tapez 1)\nNormale: Le nombre mystère est compris entre 1 et 100 (tapez 2)\nDifficile: Le nombre mystère est compris entre 1 et 500 (tapez 3)"))
    if difficulte == 1:
        nombre_mystere = randint(1,50)
    if difficulte == 2:
        nombre_mystere = randint(1,100)
    if difficulte == 3:
        nombre_mystere = randint(1,500)
    print("C'est parti !")
    essai = 0

    while essai != nombre_mystere :
        essai = int(input("Essayez un nombre: "))
        nb_coups += 1
        if essai != nombre_mystere:
            print("Ce n'est pas le bon nombre,")
            if nombre_mystere > essai :
                print("le nombre mystère est plus grand.")
            if nombre_mystere < essai :
                print("le nombre mystère est plus petit.")
        if essai == nombre_mystere :
            if difficulte == 1:
                score = (50 - nb_coups)/10*2
            if difficulte == 2:
                score = (100 - nb_coups)/10
            if difficulte == 3:
                score = (500 - nb_coups)/100*2
            print("Félicitations,",joueur," vous avez trouvez le nombre mystère en",nb_coups,"coups,")
            print("Ça vous fait un score de",score,"/10 !")

    if score > record :
        record = score
        print("Félicitations",joueur,", votre score de",score,"/10 est votre nouveau record")
    if score < record :
        print("Votre score n'est pas suffisant pour battre votre record de",record,"/10")

    reponse = input("Si vous souhaitez rejouer pour améliorer vore score, tapez 'r' pour rejouer,\nsinon, tapez n'importe quelle autre touche de votre clavier.")

print("Merci d'avoir joué au Jeu du nombre mystère.")
